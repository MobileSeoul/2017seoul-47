package kr.ac.dongyang.cs.myproject_android;

/**
 * Created by kmm on 2017-05-17.
 */

public class StepValues {
    public static int Step = 0;
}
