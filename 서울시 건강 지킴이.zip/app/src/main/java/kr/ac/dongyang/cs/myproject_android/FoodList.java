package kr.ac.dongyang.cs.myproject_android;

/**
 * Created by kmm on 2017-05-21.
 */

public class FoodList {
    String writedate;
    String strMeal[] = {"morning", "lunch", "dinner", "snack"};
    int intKcal[] = {0,0,0,0};
}
