package kr.ac.dongyang.cs.myproject_android;

/**
 * Created by kmm on 2017-05-31.
 */

public class FoodInformList {
    String name;
    int howmuch, kcal, carbo, protein,fat;
}
