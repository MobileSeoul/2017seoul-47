package kr.ac.dongyang.cs.myproject_android;

/**
 * Created by kmm on 2017-06-16.
 */

public class park {
    private double xpos;
    private double ypos;
    private String name;
    public double getXpos(){
        return xpos;
    }
    public void setXpos(double xpos){
        this.xpos = xpos;
    }
    public double getYpos(){
        return ypos;
    }
    public void setYpos(double ypos){
        this.ypos = ypos;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
}

